/* *****************************************************************************
 *  Name:              Iris Li
 *  Coursera User ID:  123456
 *  Last modified:     7/20/2021
 **************************************************************************** */

public class PercolationStats {
    // perform independent trails on an n-by-n grid
    public PercolationStats(int n, int trilas) {

    }

    // sample mean of percolation threashold
    public double mean() {

    }

    // sample standard deviation of percolation threshold
    public double stddev() {

    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {

    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {

    }


    // test client
    public static void main(String[] args) {

    }
}
